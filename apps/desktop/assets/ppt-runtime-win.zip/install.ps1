﻿# 场景通 PPT 组件安装（Windows）
# 作用：把内置的 Python 运行时 + ppt-master 技能复制到本机，并设置用户环境变量。
# 不写系统目录、不需要管理员权限；场景通重启后生效。
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA '场景通\ppt'

Write-Host "安装到：$dest"
if (Test-Path -LiteralPath $dest) {
  Remove-Item -LiteralPath $dest -Recurse -Force
}
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $src 'python') -Destination (Join-Path $dest 'python') -Recurse
Copy-Item -LiteralPath (Join-Path $src 'skill')  -Destination (Join-Path $dest 'skill')  -Recurse

$py = Join-Path $dest 'python\python.exe'
$skill = Join-Path $dest 'skill'
Write-Host "自检：$py"
& $py -c "import sys, pptx; print('Python', sys.version.split()[0], '| python-pptx', pptx.__version__)"
if ($LASTEXITCODE -ne 0) { throw 'Python 运行时自检失败，请把这段报错发回。' }

[Environment]::SetEnvironmentVariable('PPT_PYTHON', $py, 'User')
[Environment]::SetEnvironmentVariable('PPT_MASTER_DIR', $skill, 'User')
Write-Host ''
Write-Host '完成。请完全退出场景通再重新打开，然后重试「导出 PPT」。'
Write-Host "如需卸载：删除 $dest，并删掉用户环境变量 PPT_PYTHON / PPT_MASTER_DIR。"

﻿$ErrorActionPreference = 'Stop'
$dest = Join-Path $env:LOCALAPPDATA '场景通\ppt'
if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
[Environment]::SetEnvironmentVariable('PPT_PYTHON', $null, 'User')
[Environment]::SetEnvironmentVariable('PPT_MASTER_DIR', $null, 'User')
Write-Host '已卸载 PPT 组件。'

场景通 PPT 组件（Windows 免安装 Python）

用途：让「导出 PPT」不依赖你本机装 Python / pip。
内容：python\（内置 Python 3.12 + python-pptx/lxml/Pillow 等）、skill\（ppt-master 导出脚本与图标库）。

安装：
1. 解压本压缩包到任意普通目录（不要在 DSH 工作区/公司管控目录里运行）；
2. 双击「安装PPT组件.bat」；
3. 完全退出场景通，再重新打开；
4. 交付物面板点「导出 PPT」。

卸载：
双击「卸载PPT组件.bat」，或删除 %LOCALAPPDATA%\场景通\ppt，并删掉用户环境变量
PPT_PYTHON / PPT_MASTER_DIR。

注意：这是本地组件，不上传数据；只读取技能脚本生成 pptx。
